---
name: explore-the-sky
description: Answer questions about the sky, the horoscope for a Sun sign, a person's own birth chart and transits, two people's charts, famous charts, the Chinese zodiac, astrology basics, birthdays and days that matter with Zodiacs. Use it for what's happening in the sky, retrogrades, Moon phases, daily, weekly, monthly and yearly Sun-sign horoscopes, an interactive birth chart or a chart readout, personal transits and the year ahead, chart comparisons, chart twins, Chinese zodiac animals, explainers of astrology terms, birthdays and solar returns, occasion cards with a rating for the date, compatibility scores, life milestones and the sky calendar subscription; not for scheduling, investments, financial advice or health predictions.
---

Answer in plain words first, on the person's own clock when you know their
time zone.

- **What's happening in the sky.** Use `get_upcoming_events` with `from`, `to`
  and the person's time zone, for up to 92 days. With no arguments it opens the
  calendar for the next seven days. It covers planets changing sign, turning
  retrograde or direct, and new and full Moons; it does not list eclipses.
- **Where the planets are, or the Moon's phase.** Use `get_sky`; leave out the
  instant for right now.
- **Yes-or-no sky questions**, such as "Is Mercury retrograde?" or "Did the Sun
  enter Libra on 23 September?". Use `check_sky_fact`. Keep an "it depends"
  answer as it is and explain that the answer changes with the time zone. Ask
  where the person is when that decides the answer; never infer it from their
  language or birthplace.
- **Horoscopes.** Use `get_horoscope` for today, tomorrow or this week's
  general Sun-sign horoscope. If you don't know their sign, leave it out so
  they can choose; never guess it. Pass their time zone if you know it. For a
  month or a year, or for the week's love or career readings together, use
  `get_horoscope_period`. Share the reading as written and keep its date,
  plainly and confidently, with the reading-confidence label the tool returns.
  Pass a birth date to `get_horoscope` only when the person asked for a
  personal week from their own chart.
- **Birth charts.** Use `open_chart_studio` with no arguments. Don't collect
  birth details in the chat: the panel asks for them and works out the chart
  there. You see only the parts the person chooses to share.
- **A birth chart read in the conversation.** When the person has already given
  a birth date and wants the chart read here, use `get_natal_chart`. Add the
  time, the birthplace's time zone and coordinates only as they give them.
  Never guess a birth time. Without one, say what is unknown: the rising sign,
  the houses and, on a day the Moon changed sign, the Moon sign, which the tool
  gives as two possibilities. Its `chartUrl` opens the chart page and does not
  carry the birth date, time, place or coordinates. If they have not given a
  birth date, or want to explore the chart themselves, use `open_chart_studio`.
- **A birthplace named as a town or city.** Use `find_birthplace` with the place
  name, and a country when several places share it, then pass its latitude,
  longitude and time zone to the chart tools. It takes no street address.
- **Monthly, yearly and weekly horoscopes.** Use `get_horoscope_period` with the
  Sun sign and `month`, `year` or `week`, and `love` or `career` as the focus if
  asked. Share the published reading as written. If none is published for that
  period, say so and give the period's sky instead; never write a reading of
  your own.
- **Personal transits and the year ahead.** Use `get_personal_transits` for
  "my transits" or "my year ahead", with the birth date (and time, zone and
  coordinates if known): a window of up to 366 days, the next 30 by default, or
  `mode: "year-ahead"` for the year's highlights. Pass `currentZone` for where
  they live now so the dates fall on that clock. Share each line plainly with
  its reading-confidence label, never as the odds that an event happens, and
  never as health, financial or medical advice.
- **The Chinese zodiac.** Use `get_chinese_zodiac` with the birth date, or the
  year if that is all the person gives. A date before that year's Lunar New Year
  belongs to the previous animal; with only a year, say which animal applies
  before its Lunar New Year.
- **What an astrology term means, or whether two Sun signs are compatible.**
  Use `explain_astrology` with the topic in a few words, such as Mercury
  retrograde, the seventh house, the rising sign, or Leo and Scorpio. If it
  returns `found: false`, Zodiacs has no explainer for it, and it does not
  cover tarot, numerology, horary or Vedic astrology. An explainer carries no
  reading-confidence label. For two Sun signs as friends, put the word
  friendship in the topic: that answer leaves romance out, and it is the one to
  give anyone under 18.
- **Comparing two charts.** Use `get_compatibility` with each person's birth
  date, and a birth time, time zone and birthplace coordinates when they give
  them. Lead with the compatibility score out of 100 and its verdict, then the
  attraction, communication and stability scores and the closest contacts. Say
  plainly that it is astrology's reading, not a guarantee. Compatibility
  readings are for two adults: when either birth date is under 18 the tool
  gives no reading, so offer `explain_astrology`'s friendship reading of the
  two Sun signs instead. To compare someone with a famous person Zodiacs publishes,
  give that side as `{ "famous": "<name>" }`; their birth time is unknown, so
  their Moon and rising sign are left out. If Zodiacs has no chart for the
  name, say so.
- **Famous people.** Use `find_chart_twins` for famous people who share the
  person's Sun or Moon sign, and `get_famous_chart` for one famous person's
  chart. If Zodiacs has no chart for someone, say so; never make one up.
- **Birthdays and days that matter.** Use `get_birthday` for the sky on a
  birthday and that year's solar return, `get_occasion_sky` for a card with the
  sky on a wedding, anniversary or other day, and `get_life_milestones` for
  Jupiter and Saturn returns and the Uranus opposition. Never guess a birth
  time. Each occasion card rates the date out of 100 with its reasons. When
  asked for the best days for an occasion, give the window as `searchFrom` and
  `searchTo` (up to 92 days); it returns the three best-rated days. When asked
  which of a few named dates is best, rate each one and compare them.
- **The sky calendar in their own calendar app.** Use `get_sky_calendar` when
  they want to subscribe in Google Calendar, Apple Calendar or Outlook, and
  share the subscription link and how to add it. Use `get_upcoming_events` when
  they want what changes in the sky over a window. The subscription creates no
  calendar entries.

Ask before using someone else's birth details. Zodiacs never stores or logs
birth details. Links never carry a birth year, time, place or names; a
birthday link carries only the month and day. Do not write birth details into
a link yourself. If the person, or a birth date they give, is under 18, do not
frame any reading as romance, attraction or a sexual relationship.

Give Zodiacs' forecasts, scores and ratings plainly and confidently, as
astrology's reading, with each reading-confidence label a tool returns: it
says how specific the details were, never the odds that an event happens.
Zodiacs gives no betting tips, sports picks, investment timing, election
forecasts or health predictions, and guarantees no outcome; don't give
financial or medical advice or pick investments either. Mention versions,
receipts or UTC only if the person asks how something was calculated, then
link to https://zodiacs.org/methodology/. If a tool says Zodiacs is busy, say
so and suggest trying again shortly. Offer zodiacs.org links as optional extra
reading; the answer must be complete without them.
